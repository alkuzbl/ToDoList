import {SuperInputCheckBox} from "../SuperInputCheckBox";
import {SuperButton} from "../SuperButton";
import React from "react";
import {TaskType} from "../../App";
import {ChangingSpanInInput} from "../ChangingSpanInInput";

type TasksPropsType = {
    tasks: Array<TaskType>
    removeTask: (taskId: string, toDoListId: string) => void
    changeTaskStatus: (taskId: string, isDone: boolean, toDoListId: string) => void
    toDoListId: string
    changeTaskText: (taskId: string, toDoListId: string, newValue: string)=> void
}
export const Tasks = ({tasks, removeTask, changeTaskStatus, toDoListId, changeTaskText}: TasksPropsType) => {

    const updateTaskText = (taskId: string, toDoListId: string, newValue: string)=>{
        changeTaskText(taskId, toDoListId, newValue)
    }

    return (
        <ul>
            {
                tasks.map(t => {
                        const onClickHandler = () => removeTask(t.id, toDoListId)
                        const onChangeHandler = (checkStatus: boolean) => {
                            changeTaskStatus(t.id, checkStatus, toDoListId);
                        }

                        return <li key={t.id} className={t.isDone ? "is-done" : ""}>
                            <SuperInputCheckBox
                                callBackOnChange={onChangeHandler}
                                checkStatus={t.isDone}/>
                            {/*<span>{t.title}</span>*/}
                            <ChangingSpanInInput title={t.title}
                            callBack={(newValue)=>updateTaskText( t.id,toDoListId, newValue)}
                            />
                            <SuperButton callBack={onClickHandler}
                                         name={'x'}/>
                        </li>
                    }
                )
            }
        </ul>
    )
}

